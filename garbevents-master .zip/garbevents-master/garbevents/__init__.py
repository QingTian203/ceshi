from garbevents.version import __version__

"""
This is a python toolkit for real-time capture,
analysis, cleaning and report generation of embedded points based on the development of mitmproxy.

"""